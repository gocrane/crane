# Crane 训练营实验手册

## 实验内容介绍

随着云原生技术的发展，越来越多的公司正在选择将应用运行在云上或者自建的 Kubernetes 集群上，但是许多机构的调研发现，绝大多数的用户集群资源利用率并不高，浪费严重。本次训练营将会演示如何快速搭建一个 Kubernetes+Crane 环境，以及如何基于 Crane 优化你的集群和应用。

## 相关系统介绍

### Kubernetes

Kubernetes 是一个强大且灵活的平台，可以帮助您轻松地管理容器化应用程序并扩展它们。 它提供了许多功能和工具来简化部署、扩展和管理应用程序。 您可以使用 Kubernetes 来自动化部署、扩展和管理容器化应用程序，并确保它们始终按预期方式运行。 Kubernetes 还提供了许多功能和工具来简化部署、扩展和管理应用程序。 它还提供了许多功能和工具来帮助您监视和调试应用程序，并确保它们始终按预期方式运行。

![k8s](k8s.png)

### Crane

Crane 是一个基于 FinOps 的云资源分析与成本优化平台。它的愿景是在保证客户应用运行质量的前提下实现极致的降本。

#### 主要功能

![Crane Overview](crane-overview.png)

**成本可视化和优化评估**

- 提供一组 Exporter 计算集群云资源的计费和账单数据并存储到你的监控系统，比如 Prometheus。
- 多维度的成本洞察，优化评估。通过 `Cloud Provider` 支持多云计费。

**推荐框架**

提供了一个可扩展的推荐框架以支持多种云资源的分析，内置了多种推荐器：资源推荐，副本推荐，HPA 推荐，闲置资源推荐。

**基于预测的水平弹性器**

EffectiveHorizontalPodAutoscaler 支持了预测驱动的弹性。它基于社区 HPA 做底层的弹性控制，支持更丰富的弹性触发策略（预测，观测，周期），让弹性更加高效，并保障了服务的质量。

**负载感知的调度器**

动态调度器根据实际的节点利用率构建了一个简单但高效的模型，并过滤掉那些负载高的节点来平衡集群。

**拓扑感知的调度器**

Crane Scheduler与Crane Agent配合工作，支持更为精细化的资源拓扑感知调度和多种绑核策略，可解决复杂场景下“吵闹的邻居问题"，使得资源得到更合理高效的利用。

**基于 QOS 的混部**

QOS相关能力保证了运行在 Kubernetes 上的 Pod 的稳定性。具有多维指标条件下的干扰检测和主动回避能力，支持精确操作和自定义指标接入；具有预测算法增强的弹性资源超卖能力，复用和限制集群内的空闲资源；具备增强的旁路cpuset管理能力，在绑核的同时提升资源利用效率。

#### 整体架构

Crane 的整体架构如下：

![Crane Arch](crane-arch.png)

**Craned**

Craned 是 Crane 的最核心组件，它管理了 CRDs 的生命周期以及API。Craned 通过 `Deployment` 方式部署且由两个容器组成：

- Craned: 运行了 Operators 用来管理 CRDs，向 Dashboard 提供了 WebApi，Predictors 提供了 TimeSeries API
- Dashboard: 基于 TDesign's Starter 脚手架研发的前端项目，提供了易于上手的产品功能

**Fadvisor**

Fadvisor 提供一组 Exporter 计算集群云资源的计费和账单数据并存储到你的监控系统，比如 Prometheus。Fadvisor 通过 `Cloud Provider` 支持了多云计费的 API。

**Metric Adapter**

Metric Adapter 实现了一个 `Custom Metric Apiserver`. Metric Adapter 读取 CRDs 信息并提供基于 `Custom/External Metric API` 的 HPA Metric 的数据。

**Crane Agent**

Crane Agent 通过 `DaemonSet` 部署在集群的节点上。

## Repositories

Crane is composed of the following components:

- [craned](https://github.com/gocrane/crane/tree/main/cmd/craned) - main crane control plane.
- [metric-adaptor](https://github.com/gocrane/crane/tree/main/cmd/metric-adapter) - Metric server for driving the scaling.
- [crane-agent](https://github.com/gocrane/crane/tree/main/cmd/crane-agent) - Ensure critical workloads SLO based on abnormally detection.
- [api](https://github.com/gocrane/api) - This repository defines component-level APIs for the Crane platform.
- [fadvisor](https://github.com/gocrane/fadvisor) - Financial advisor which collect resource prices from cloud API.
- [crane-scheduler](https://github.com/gocrane/crane-scheduler) - A Kubernetes scheduler which can schedule pod based on actual node load.
- [kubectl-crane](https://github.com/gocrane/kubectl-crane) - Kubectl plugin for crane, including recommendation and cost estimate.

### Prometheus

Prometheus 受启发于 Google 的 Brogmon 监控系统（相似的Kubernetes是从Google的Brog系统演变而来），从2012年开始由前Google工程师在Soundcloud以开源软件的形式进行研发，并且于2015年早期对外发布早期版本。2016年5月继Kubernetes之后成为第二个正式加入CNCF基金会的项目，同年6月正式发布1.0版本。2017年底发布了基于全新存储层的2.0版本，能更好地与容器平台、云平台配合。

### Grafana

Grafana 是一个监控仪表系统，它是由 Grafana Labs 公司开源的的一个系统监测工具，它可以大大帮助我们简化监控的复杂度，我们只需要提供需要监控的数据，它就可以帮助生成各种可视化仪表，同时它还有报警功能，可以在系统出现问题时发出通知。

## 实验步骤

### 实验准备步骤 (课前准备)

**安装 kubectl**

请参考官方文档依据你的本地环境系统参考对应的文档安装 kubectl：https://kubernetes.io/zh-cn/docs/tasks/tools/

**安装 Helm**

请参考官方文档依据你的本地环境系统参考对应的文档安装 Helm：https://helm.sh/zh/docs/intro/install/

**安装 kind**

请参考官方文档依据你的本地环境系统参考对应的文档安装 kind：https://kind.sigs.k8s.io/docs/user/quick-start/#installation

**安装 Docker**

请参考官方文档依据你的本地环境系统参考对应的文档安装 docker：https://docs.docker.com/get-docker/

### 本地安装 Crane

#### 安装本地的 Kind 集群和 Crane 组件

以下命令将安装 Crane 以及其依赖 (Prometheus/Grafana).

```bash
curl -sf https://raw.githubusercontent.com/gocrane/crane/main/hack/local-env-setup.sh | sh -
```

如果上面安装命令报网络错误，可以用本地的安装包执行安装，在命令行中执行以下安装命令：

```shell
bash installation/local-env-setup.sh
```

确保所有 Pod 都正常运行:

```bash
$ export KUBECONFIG=${HOME}/.kube/config_crane
$ kubectl get deploy -n crane-system
NAME                                             READY   STATUS    RESTARTS       AGE
crane-agent-5r9l2                                1/1     Running   0              4m40s
craned-6dcc5c569f-vnfsf                          2/2     Running   0              4m41s
fadvisor-5b685f4cd6-xpxzq                        1/1     Running   0              4m37s
grafana-64656f6d54-6l24j                         1/1     Running   0              4m46s
metric-adapter-967c6d57f-swhfv                   1/1     Running   0              4m41s
prometheus-kube-state-metrics-7f9d78cffc-p8l7c   1/1     Running   0              4m46s
prometheus-node-exporter-4wk8b                   1/1     Running   0              4m40s
prometheus-server-fb944f4b7-4qqlv                2/2     Running   0              4m46s
```

#### 访问 Crane Dashboard

```bash
kubectl -n crane-system port-forward service/craned 9090:9090
```

点击 [这里](http://127.0.0.1:9090/) 访问 Crane Dashboard

![](/images/dashboard.png)

添加本地集群:

![add-cluster.png](addcluster.png)

### 使用智能弹性 EffectiveHPA

Kubernetes HPA 支持了丰富的弹性扩展能力，Kubernetes 平台开发者部署服务实现自定义 Metric 的服务，Kubernetes 用户配置多项内置的资源指标或者自定义 Metric 指标实现自定义水平弹性。

EffectiveHorizontalPodAutoscaler（简称 EHPA）是 Crane 提供的弹性伸缩产品，它基于社区 HPA 做底层的弹性控制，支持更丰富的弹性触发策略（预测，观测，周期），让弹性更加高效，并保障了服务的质量。 
- 提前扩容，保证服务质量：通过算法预测未来的流量洪峰提前扩容，避免扩容不及时导致的雪崩和服务稳定性故障。
- 减少无效缩容：通过预测未来可减少不必要的缩容，稳定工作负载的资源使用率，消除突刺误判。
- 支持 Cron 配置：支持 Cron-based 弹性配置，应对大促等异常流量洪峰。
- 兼容社区：使用社区 HPA 作为弹性控制的执行层，能力完全兼容社区。

**安装Metrics Server**

用以下命令安装 Metrics Server：

```shell
kubectl apply -f installation/components.yaml
kubectl get pod -n kube-system
```

**创建测试应用**

用以下命令启动一个 Deployment 用 hpa-example 镜像运行一个容器， 然后将其暴露为一个 服务（Service）：

```shell
kubectl apply -f https://raw.githubusercontent.com/gocrane/crane/main/examples/autoscaling/php-apache.yaml
kubectl apply -f https://raw.githubusercontent.com/gocrane/crane/main/examples/analytics/nginx-deployment.yaml
```

**创建 EffectiveHPA**

```shell
kubectl apply -f https://raw.githubusercontent.com/gocrane/crane/main/examples/autoscaling/effective-hpa.yaml
```

运行以下命令查看 EffectiveHPA 的当前状态：

```shell
kubectl get ehpa
```

输出类似于:

```shell
NAME         STRATEGY   MINPODS   MAXPODS   SPECIFICPODS   REPLICAS   AGE
php-apache   Auto       1         10                       0          3m39s
```

**增加负载**

```shell
# 在单独的终端中运行它
# 以便负载生成继续，你可以继续执行其余步骤
kubectl run -i --tty load-generator --rm --image=busybox:1.28 --restart=Never -- /bin/sh -c "while sleep 0.01; do wget -q -O- http://php-apache; done"
```

现在执行：

```shell
# 准备好后按 Ctrl+C 结束观察
kubectl get hpa ehpa-php-apache --watch
```

随着请求增多，CPU利用率会不断提升，可以看到 EffectiveHPA 会自动扩容实例。

说明：预测数据需要两天以上的监控数据才能出现。

### 成本展示 

Crane Dashboard 提供了各式各样的图表展示了集群的成本和资源用量，

**集群总览**

![overview.png](overview.png)

- 当月总成本：过去一个月集群总成本。从安装Crane时间开始，按小时累加集群成本
- 预估每月成本：以最近一小时成本估算未来一个月的成本。每小时成本 * 24 * 30
- 预估CPU总成本：以最近一小时CPU成本估算未来一个月的CPU成本。每小时CPU成本 * 24 * 30
- 预估Memory总成本：以最近一小时Memory成本估算未来一个月的Memory成本。每小时Memory成本 * 24 * 30

**成本洞察->集群总览**

![cluster-overview.png](clusteroverview.png)

**成本洞察->集群总览**

![workload-overview.png](workloadoverview.png)

- Workload Spec CPU Slack: Workload 的 CPU 规格 - 推荐的 CPU 规格
- Workload Total CPU Slack: （Workload 的 CPU 规格 - 推荐的 CPU 规格）* Pod 数量

更多的成本分析图表可以通过登陆 Grafana 的页面或者分析源码研究。

登陆 Grafana 的方式可以通过以下命令建立一个 port-mapping：

```shell
kubectl -n crane-system port-forward service/grafana 8082:8082
```

访问本地 Grafana（账号密码:admin/admin）： http://127.0.0.1:8082/grafana/login

### 如何计算成本

成本计算功能是由组件 Fadvisor 实现，在安装 Crane 时会一起安装，一起提供了成本展示和成本分析功能：

- Server：收集集群 Metric 数据并计算成本
- Exporter：将成本 Metric 暴露出来

![fadvisor.png](fadvisor.png)

**原理**

Fadvisor 成本模型提供了一个方法来估计和分析每个容器,pod 或其他资源在 Kubernetes 中的资源价格。

请注意,成本模型只是预估成本,而不是替代云订单,因为实际的计费数据取决于更多原因，比如各类计费逻辑。以下是计算理论：

- 最简单的成本模型是以相同的价格估算所有节点或 pod 的资源价格。例如,在计算成本时,您可以假设所有容器的 CPU 和 RAM 单位价格相同,2$/小时核心,0.3$/小时 Gib
- 高级成本模型是通过成本分摊来估计资源价格。 这一理论的基础是不同实例类型和计费类型的每个云机器实例的价格不同，不过 CPU 和 RAM 的价格比率是相对固定的，可以通过这个价格比率来计算资源成本。

成本分摊模型下的具体的计算公式如下：

- 集群整体成本：cvm 成本之和
- CPU/mem 价格比率相对固定
- cvm 的成本 = CPU 成本 * CPU 数量 + mem 成本 * mem 数量
- CPU 申请成本：整体成本 * （CPU 占 cvm 成本的比例）得到整体 CPU 成本，再按申请的 CPU 总览占整体 CPU 总量的比例计算出 CPU 申请的成本
- namespace 下的 CPU 申请成本： CPU 申请成本按 namespace 聚合

### 优化你的应用配置

在 dashboard 中开箱后就可以看到相关的成本数据，是因为在添加集群的时候我们安装了推荐的规则。

推荐框架会自动分析集群的各种资源的运行情况并给出优化建议。Crane 的推荐模块会定期检测发现集群资源配置的问题，并给出优化建议。智能推荐提供了多种 Recommender 来实现面向不同资源的优化推荐。

在`成本分析>推荐规则`页面可以看到我们安装的两个推荐规则。

![recommendationrule.png](recommendationrule.png)

这些推荐规则实际上在将 K8s 集群接入Dashboard时安装上的 RecommendationRule CRD 对象：

```shell
$ kubectl get RecommendationRule
NAME             RUNINTERVAL   AGE
idlenodes-rule   24h           16m
workloads-rule   24h           16m
```

workloads-rule 这个推荐规则的资源对象如下所示：

```shell
apiVersion: analysis.crane.io/v1alpha1
kind: RecommendationRule
metadata:
  name: workloads-rule
  labels:
    analysis.crane.io/recommendation-rule-preinstall: "true"
spec:
  resourceSelectors:
    - kind: Deployment
      apiVersion: apps/v1
    - kind: StatefulSet
      apiVersion: apps/v1
  namespaceSelector:
    any: true
  runInterval: 24h
  recommenders:
    - name: Replicas
    - name: Resource
```

`RecommendationRule` 是一个全部范围内的对象，该推荐规则会对所有命名空间中的 Deployments 和 StatefulSets 做资源推荐和副本数推荐。相关规范属性如下所示：

- 每隔 24 小时运行一次分析推荐，runInterval 格式为时间间隔，比如: 1h，1m，设置为空表示只运行一次。
- 待分析的资源通过配置 resourceSelectors 数组设置，每个 resourceSelector 通过 kind、apiVersion、name 选择 K8s 中的资源，当不指定 name 时表示在 namespaceSelector 基础上的所有资源。
- namespaceSelector 定义了待分析资源的命名空间，any: true 表示选择所有命名空间。
- recommenders 定义了待分析的资源需要通过哪些 Recommender 进行分析。目前支持两种 Recommender： 
  - 资源推荐(Resource): 通过 VPA 算法分析应用的真实用量推荐更合适的资源配置 
  - 副本数推荐(Replicas): 通过 HPA 算法分析应用的真实用量推荐更合适的副本数量
  
**资源推荐**

Kubernetes 用户在创建应用资源时常常是基于经验值来设置 request 和 limit，通过资源推荐的算法分析应用的真实用量推荐更合适的资源配置，你可以参考并采纳它提升集群的资源利用率。该推荐算法模型采用了 VPA 的滑动窗口（Moving Window）算法进行推荐：

- 通过监控数据，获取 Workload 过去一周（可配置）的 CPU 和内存的历史用量。
- 算法考虑数据的时效性，较新的数据采样点会拥有更高的权重。
- CPU 推荐值基于用户设置的目标百分位值计算，内存推荐值基于历史数据的最大值。

**副本数推荐**

Kubernetes 用户在创建应用资源时常常是基于经验值来设置副本数。通过副本数推荐的算法分析应用的真实用量推荐更合适的副本配置，同样可以参考并采纳它提升集群的资源利用率。其实现的基本算法是基于工作负载历史 CPU 负载，找到过去七天内每小时负载最低的 CPU 用量，计算按 50%（可配置）利用率和工作负载 CPU Request 应配置的副本数。

**推荐配置**

当我们部署 crane 的时候会在同一个命名空间中创建一个名为 recommendation-configuration 的 ConfigMap 对象，包含一个 yaml 格式的 RecommendationConfiguration，该配置订阅了 recommender 的配置，如下所示：

```yaml
$ kubectl get cm recommendation-configuration -n crane-system -oyaml
apiVersion: v1
data:
  config.yaml: |-
    apiVersion: analysis.crane.io/v1alpha1
    kind: RecommendationConfiguration
    recommenders:
      - name: Replicas  # 副本数推荐
        acceptedResources:
          - kind: Deployment
            apiVersion: apps/v1
          - kind: StatefulSet
            apiVersion: apps/v1
      - name: Resource  # 资源推荐
        acceptedResources:
          - kind: Deployment
            apiVersion: apps/v1
          - kind: StatefulSet
            apiVersion: apps/v1
kind: ConfigMap
metadata:
  name: recommendation-configuration
  namespace: crane-system
```

需要注意的是资源类型和 recommenders 需要可以匹配，比如 Resource 推荐默认只支持 Deployments 和 StatefulSets。

同样的也可以再查看一次闲置节点推荐规则的资源对象，如下所示：

```yaml
$ kubectl get recommendationrule idlenodes-rule -oyaml
apiVersion: analysis.crane.io/v1alpha1
kind: RecommendationRule
metadata:
  labels:
    analysis.crane.io/recommendation-rule-preinstall: "true"
  name: idlenodes-rule
spec:
  namespaceSelector:
    any: true
  recommenders:
  - name: IdleNode
  resourceSelectors:
  - apiVersion: v1
    kind: Node
  runInterval: 24h
```

创建 RecommendationRule 配置后，RecommendationRule 控制器会根据配置定期运行推荐任务，给出优化建议生成 Recommendation 对象，然后我们可以根据优化建议 Recommendation 调整资源配置。

比如我们这里集群中已经生成了多个优化建议 Recommendation 对象。

```shell
kubectl get recommendations -A
NAME                            TYPE       TARGETKIND    TARGETNAMESPACE   TARGETNAME       STRATEGY   PERIODSECONDS   ADOPTIONTYPE          AGE
workloads-rule-resource-8whzs   Resource   StatefulSet   default           nacos            Once                       StatusAndAnnotation   34m
workloads-rule-resource-hx4cp   Resource   StatefulSet   default           redis-replicas   Once                       StatusAndAnnotation   34m
```

可以随便查看任意一个优化建议对象。

```shell
$ kubectl get recommend workloads-rule-resource-g7nwp -n crane-system -oyaml
apiVersion: analysis.crane.io/v1alpha1
kind: Recommendation
metadata:
  name: workloads-rule-resource-g7nwp
  namespace: crane-system
spec:
  adoptionType: StatusAndAnnotation
  completionStrategy:
    completionStrategyType: Once
  targetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: fadvisor
    namespace: crane-system
  type: Resource
status:
  action: Patch
  conditions:
  - lastTransitionTime: "2022-10-20T07:43:49Z"
    message: Recommendation is ready
    reason: RecommendationReady
    status: "True"
    type: Ready
  currentInfo: '{"spec":{"template":{"spec":{"containers":[{"name":"fadvisor","resources":{"requests":{"cpu":"0","memory":"0"}}}]}}}}'
  lastUpdateTime: "2022-10-20T07:43:49Z"
  recommendedInfo: '{"spec":{"template":{"spec":{"containers":[{"name":"fadvisor","resources":{"requests":{"cpu":"114m","memory":"120586239"}}}]}}}}'
  recommendedValue: |
    resourceRequest:
      containers:
      - containerName: fadvisor
        target:
          cpu: 114m
          memory: "120586239"
  targetRef: {}
```

在 dashboard 的`资源推荐`页面也能查看到优化建议列表。

![recommends.png](recommend.png)

通过`查看监控`查看详细的监控数据。

![workload-insight.png](workloadinsight.png)

在页面中可以看到当前资源(容器/CPU/Memory)与推荐的资源数据，点击采纳建议即可获取优化的执行命令。

![applyrecommend.png](applyrecommend.png)

执行命令即可完成优化，其实就是修改资源对象的 resources 资源数据。

```shell
patchData=`kubectl get recommend workloads-rule-resource-g7nwp -n crane-system -o jsonpath='{.status.recommendedInfo}'`;kubectl patch Deployment fadvisor -n crane-system --patch "${patchData}"
```

对于闲置节点推荐，由于节点的下线在不同平台上的步骤不同，用户可以根据自身需求进行节点的下线或者缩容。

应用在监控系统（比如 Prometheus）中的历史数据越久，推荐结果就越准确，建议生产上超过两周时间。对新建应用的预测往往不准。

## 实验环境清理

动手实验完成后，可以将本地的集群清理删除：

```shell
kind delete cluster --name=crane
```

